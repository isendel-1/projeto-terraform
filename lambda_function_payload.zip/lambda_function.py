def lambda_metodo(event, context):
    print(context)
    print(event)
    print("Sou uma função lambda que subi com o terraform! vamo simbora!");
